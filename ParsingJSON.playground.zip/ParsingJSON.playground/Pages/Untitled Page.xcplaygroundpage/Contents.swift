//: Playground - noun: a place where people can play

import UIKit

let json = """
{
    "meta": {
      "total": 406
    },
    "drugs": [
    {
    "id": "12547-0204",
    "active_ingredient_strength": "10mg",
    "proprietary_name": "Zyrtec",
    "non_proprietary_name": "Zyrtec"
    },
    {
    "id": "52959-0482",
    "active_ingredient_strength": "10mg",
    "proprietary_name": "Zyrtec",
    "non_proprietary_name": "Zyrtec"
    },
    {
    "id": "52959-0482",
    "active_ingredient_strength": "10mg",
    "proprietary_name": "Zyrtec",
    "non_proprietary_name": "Zyrtec"
    },
    {
    "id": "52959-0482",
    "active_ingredient_strength": "10mg",
    "proprietary_name": "Zyrtec",
    "non_proprietary_name": "Zyrtec"
    }
    ]
}
""".data(using: .utf8)!

struct DrugSearchResponse: Codable {
    let meta: Meta
    let drugs: [Drugs]

struct Meta: Codable {
    let total: Int
    }
struct Drugs: Codable {
    let id: String
    let active_ingredient_strength: String
    let proprietary_name: String
    let non_proprietary_name: String
    }
}


let decoder = JSONDecoder()

let employee = try! decoder.decode(DrugSearchResponse.self, from: json)
let drugs = employee.drugs
for name in drugs {
    print(name.proprietary_name)
}

